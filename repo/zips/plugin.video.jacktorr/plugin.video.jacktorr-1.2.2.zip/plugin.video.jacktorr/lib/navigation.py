import logging
import os
import re
from threading import Thread
import time
from urllib.parse import parse_qs, urlsplit

import requests
from lib.torrserver.api import TorrServer, TorrServerError
from lib.torrserver.display_metadata import (
    delete_display_metadata,
    get_display_metadata,
    prune_display_metadata,
    save_display_metadata,
)
import routing
from xbmc import Monitor, executebuiltin, getInfoLabel, getCondVisibility, sleep
from xbmcgui import ListItem, DialogProgress, Dialog
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl

from lib.buffering import (
    MAX_RETRIES_DEFAULT,
    clamp_progress,
    is_retryable_error,
    backoff_seconds,
    compute_buffering_progress,
    is_preload_complete,
    is_resolving_metadata,
)
from lib.dialog import DialogInsert
from lib.episode_matching import match_episode_file
from lib.kodi import (
    ADDON_PATH,
    ADDON_NAME,
    translate,
    notification,
    set_logger,
    refresh,
    show_picture,
    close_busy_dialog,
    set_info_tag,
)
from lib.kodi_formats import (
    is_music,
    is_picture,
    is_video,
    is_text,
    is_displayable,
    strip_common_folder_prefix,
)
from lib.player import JackTorrPlayer
from lib.search_history import load_history, add_search, clear_history
from lib.settings import (
    get_password,
    get_service_host,
    get_port,
    get_buffering_timeout,
    get_buffer_retries,
    get_username,
    show_status_overlay,
    get_min_candidate_size,
    ask_to_delete_torrent,
    get_files_order,
    hide_subfolder_components,
    get_metadata_timeout,
    ssl_enabled,
)
from lib.utils import sizeof_fmt

set_logger()
plugin = routing.Plugin()


api = TorrServer(
    get_service_host(), get_port(), get_username(), get_password(), ssl_enabled()
)
logging.info("JackTorr api singleton created with base_url=%s", api._base_url)


class PlayError(Exception):
    def handle(self):
        pass


class CanceledError(PlayError):
    def __init__(self, e, info_hash, name):
        super(CanceledError, self).__init__(e)
        self._info_hash = info_hash
        self._name = name

    def handle(self):
        handle_player_stop(self._info_hash, self._name)


def check_playable(func):
    def wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except Exception as e:
            if not getattr(e, "%_checked", False):
                setResolvedUrl(plugin.handle, False, ListItem())
                if isinstance(e, PlayError):
                    logging.debug(e)
                    e.handle()
                    return
                setattr(e, "%_checked", True)
            raise e

    return wrapper


def check_directory(func):
    def wrapper(*args, **kwargs):
        succeeded = False
        try:
            ret = func(*args, **kwargs)
            succeeded = True
            return ret
        finally:
            endOfDirectory(plugin.handle, succeeded=succeeded)

    return wrapper


def li(tid, icon):
    return list_item(translate(tid), icon)


def list_item(label, icon, poster=None):
    item = ListItem(label)
    art = {"icon": os.path.join(ADDON_PATH, "resources", "images", icon)}
    if poster:
        art["poster"] = poster
    item.setArt(art)
    return item


def action(func, *args, **kwargs):
    return "RunPlugin({})".format(plugin.url_for(func, *args, **kwargs))


def media(func, *args, **kwargs):
    return "PlayMedia({})".format(plugin.url_for(func, *args, **kwargs))


def query_arg(name, required=True):
    def decorator(func):
        def wrapper(*args, **kwargs):
            if name not in kwargs:
                query_list = plugin.args.get(name)
                if query_list:
                    kwargs[name] = query_list[0]
                elif required:
                    raise AttributeError(
                        "Missing {} required query argument".format(name)
                    )
            return func(*args, **kwargs)

        return wrapper

    return decorator


def get_state_string(state):
    if state == 0:
        return "Torrent added"
    elif state == 1:
        return "Torrent getting info"
    elif state == 2:
        return "Torrent preload"
    elif state == 3:
        return "Torrent working"
    elif state == 4:
        return "Torrent closed"
    elif state == 5:
        return "Torrent in db"
    else:
        return translate(30230)


def get_status_labels(info_hash):
    info = api.get_torrent_info(info_hash)
    return (
        "{:s}".format(get_state_string(info.get("stat"))),
        "D:{:s}/s U:{:s}/s S:{:d} P:{:d}/{:d}".format(
            sizeof_fmt(info.get("download_speed")),
            sizeof_fmt(info.get("upload_speed")),
            info.get("connected_seeders"),
            info.get("active_peers"),
            info.get("total_peers"),
        ),
    )


def handle_player_stop(info_hash, name, initial_delay=0.5, listing_timeout=10):
    if not ask_to_delete_torrent():
        return

    sleep(int(initial_delay * 1000))
    start_time = time.time()
    while (
        getCondVisibility("Window.IsActive(busydialog)")
        and not 0 < listing_timeout < time.time() - start_time
    ):
        sleep(100)

    remove_torrent = Dialog().yesno(translate(30242), translate(30241))
    if remove_torrent:
        response = api.remove_torrent(info_hash)
        if getattr(response, "status_code", None) == 200:
            delete_display_metadata(api._base_url, info_hash)
        current_folder = getInfoLabel("Container.FolderPath")
        if current_folder == plugin.url_for(torrent_files, info_hash):
            executebuiltin("Action(Back)")
        elif current_folder == plugin.url_for(torrents):
            refresh()


@plugin.route("/")
@check_directory
def index():
    try:
        api.torr_version
    except Exception:
        notification(translate(30247))
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(search_results),
        li(30255, "search.png"),
        isFolder=True,
    )    
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(dialog_insert),
        li(30207, "add.png"),
        isFolder=False,
    )
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(torrents),
        li(30206, "torrents.png"),
        isFolder=True,
    )
    
@plugin.route("/torrents")
@check_directory
def torrents():
    torrent_list = api.torrents()
    prune_display_metadata(api._base_url)
    categories = {torrent_category(torrent) for torrent in torrent_list}
    for category in sorted(categories, key=lambda value: (value is not None, value or "")):
        label = category if category is not None else translate(30260)
        if category is None:
            url = plugin.url_for(uncategorized_torrents)
        else:
            url = plugin.url_for(category_torrents, category=category)
        addDirectoryItem(
            plugin.handle,
            url,
            list_item(label, "torrents.png"),
            isFolder=True,
        )


@plugin.route("/torrents/category")
@query_arg("category")
@check_directory
def category_torrents(category):
    list_category_torrents(category)


@plugin.route("/torrents/uncategorized")
@check_directory
def uncategorized_torrents():
    list_category_torrents(None)


def torrent_category(torrent):
    category = torrent.get("category") if isinstance(torrent, dict) else None
    return category if isinstance(category, str) and category else None


def list_category_torrents(category):
    torrent_list = api.torrents()
    prune_display_metadata(api._base_url)
    for torrent in torrent_list:
        if torrent_category(torrent) == category:
            add_torrent_item(torrent)


def add_torrent_item(torrent):
    info_hash = torrent.get("hash")
    display_metadata = get_display_metadata(api._base_url, info_hash)
    display_title = display_metadata.get("title") or torrent.get("title", "")
    display_plot = display_metadata.get("plot", "")
    display_poster = display_metadata.get("poster") or torrent.get("poster")

    context_menu_items = [
        (translate(30235), media(play_info_hash, info_hash=info_hash))
    ]

    if torrent.get("stat") in [2, 3]:
        context_menu_items.append(
            (translate(30208), action(torrent_action, info_hash, "drop"))
        )

    context_menu_items.extend(
        [
            (
                translate(30242),
                action(torrent_action, info_hash, "remove_torrent"),
            ),
            (
                translate(30245),
                action(torrent_action, info_hash, "torrent_status"),
            ),
        ]
    )

    context_menu_items.append(
        (translate(30248), action(torrent_action, info_hash, "set_poster"))
    )
    context_menu_items.append(
        (translate(30250), action(torrent_action, info_hash, "set_category"))
    )

    torrent_li = list_item(
        display_title, "download.png", poster=display_poster
    )
    set_info_tag(torrent_li, "video", {"title": display_title, "plot": display_plot})
    torrent_li.addContextMenuItems(context_menu_items)
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(torrent_files, info_hash),
        torrent_li,
        isFolder=True,
    )


@plugin.route("/torrents/<info_hash>/<action_str>")
def torrent_action(info_hash, action_str):
    needs_refresh = True

    if action_str == "drop":
        api.drop_torrent(info_hash)
    elif action_str == "remove_torrent":
        response = api.remove_torrent(info_hash)
        if getattr(response, "status_code", None) == 200:
            delete_display_metadata(api._base_url, info_hash)
    elif action_str == "torrent_status":
        torrent_status(info_hash)
        needs_refresh = False
    elif action_str == "set_poster":
        poster_url = Dialog().input(translate(30249))
        if poster_url:
            api.set_torrent(info_hash, poster=poster_url)
        else:
            needs_refresh = False
    elif action_str == "set_category":
        category = Dialog().input(translate(30251))
        if category:
            api.set_torrent(info_hash, category=category)
        else:
            needs_refresh = False
    else:
        logging.error("Unknown action '%s'", action_str)
        needs_refresh = False

    if needs_refresh:
        refresh()


@plugin.route("/new_search")
def new_search():
    query = Dialog().input(translate(30252))
    if not query:
        logging.info("Search: user cancelled input dialog")
        endOfDirectory(plugin.handle, succeeded=False)
        return
    # Record the term so it appears in the history next time.
    add_search(query)
    executebuiltin(
        "Container.Update({}, replace)".format(
            plugin.url_for(search_results, query=query)
        )
    )


@plugin.route("/clear_search_history")
def clear_search_history():
    from lib.search_history import clear_history as _clear

    _clear()
    logging.info("Search: history cleared")
    executebuiltin("Container.Refresh")
    endOfDirectory(plugin.handle, succeeded=True)


@plugin.route("/search_results")
@query_arg("query", required=False)
@check_directory
def search_results(query=None):
    if not query:
        logging.info("Search: /search_results reached with no query")
        item = li(30256, "download.png")
        item.setProperty("IsPlayable", "false")
        addDirectoryItem(
            plugin.handle,
            plugin.url_for(new_search),
            item,
            isFolder=False,
        )
        for term in load_history():
            addDirectoryItem(
                plugin.handle,
                plugin.url_for(search_results, query=term),
                list_item(term, "download.png"),
                isFolder=True,
            )
        item = li(30257, "download.png")
        item.setProperty("IsPlayable", "false")
        addDirectoryItem(
            plugin.handle,
            plugin.url_for(clear_search_history),
            item,
            isFolder=False,
        )
        return
    try:
        results = api.search(query)
    except TorrServerError as e:
        logging.warning("Search: TorrServerError: %s", e)
        notification(str(e))
        return
    logging.info(
        "Search: query=%r returned %d results",
        query,
        len(results) if hasattr(results, "__len__") else -1,
    )
    if not results:
        logging.info("Search: no results, showing notification")
        notification(translate(30253))
        return
    for r in results:
        magnet = r.get("Magnet", "")
        if not magnet:
            continue
        title = r.get("Title", "") or r.get("Name", "")
        size = r.get("Size", "")
        # Size is a human-readable string ("42.93 GB"), not bytes.
        label = "{} ({})".format(title, size) if size else title
        item = list_item(label, "download.png")
        item.setProperty("IsPlayable", "true")
        context_menu_items = [
            (translate(30254), media(play_magnet, magnet=magnet, poster=""))
        ]
        item.addContextMenuItems(context_menu_items)
        url = plugin.url_for(play_magnet, magnet=magnet, buffer=True, poster="")
        addDirectoryItem(plugin.handle, url, item, isFolder=False)


@plugin.route("/torrents/<info_hash>/files/<file_id>/<action_str>")
def file_action(info_hash, file_id, action_str):
    if action_str == "download":
        api.download_file(info_hash, file_id)
    elif action_str == "drop":
        api.drop_torrent(info_hash)
    else:
        logging.error("Unknown action '%s'", action_str)
        return
    refresh()


@plugin.route("/set_poster")
@query_arg("info_hash")
@query_arg("poster")
def set_poster(info_hash, poster):
    api.set_torrent(info_hash, poster=poster)
    notification(translate(30243), time=2000)
    refresh()


def torrent_status(info_hash):
    status = api.get_torrent_info(link=info_hash)
    notification(
        "{}".format(status.get("stat_string")),
        status.get("name"),
        sound=False,
    )


def sort_files(files):
    order = get_files_order()
    if order == 1:
        files.sort(key=lambda k: k.name)
    elif order == 2:
        files.sort(key=lambda k: k.length)


def _magnet_info_hash(magnet):
    try:
        for value in parse_qs(urlsplit(magnet).query).get("xt", []):
            prefix = "urn:btih:"
            if value.lower().startswith(prefix):
                info_hash = value[len(prefix) :]
                if re.fullmatch(r"[0-9a-fA-F]{40}", info_hash):
                    return info_hash
    except (TypeError, ValueError):
        pass
    return ""


@plugin.route("/torrents/<info_hash>")
@check_directory
def torrent_files(info_hash):
    info = api.get_torrent_info(link=info_hash)
    display_metadata = get_display_metadata(api._base_url, info_hash)
    display_title = display_metadata.get("title") or info.get("title", "")
    display_plot = display_metadata.get("plot", "")
    display_poster = display_metadata.get("poster") or info.get("poster")
    file_stats = info.get("file_stats")
    file_stats = [f for f in file_stats if is_displayable(f.get("path", ""))]
    display_names = strip_common_folder_prefix(
        file_stats, hide_subfolder_components=hide_subfolder_components()
    )

    for f, display_name in zip(file_stats, display_names):
        name = f.get("path")
        id = f.get("id")
        serve_url = api.get_stream_url(link=info_hash, path=f.get("path"), file_id=id)
        file_li = list_item(display_name, "download.png", poster=display_poster)
        file_li.setPath(serve_url)

        context_menu_items = []
        info_labels = {"title": display_title, "plot": display_plot}
        kwargs = dict(info_hash=info_hash, file_id=id, path=name)

        if is_picture(name):
            url = plugin.url_for(display_picture, **kwargs)
            set_info_tag(file_li, "pictures", info_labels)
        elif is_text(name):
            url = plugin.url_for(display_text, **kwargs)
        else:
            url = serve_url
            if is_video(name):
                info_type = "video"
            elif is_music(name):
                info_type = "music"
            else:
                info_type = None

            if info_type is not None:
                url = plugin.url_for(buffer_and_play, **kwargs)
                set_info_tag(file_li, info_type, info_labels)
                file_li.setProperty("IsPlayable", "true")

                context_menu_items.append(
                    (translate(30235), media(buffer_and_play, **kwargs))
                )

        file_li.addContextMenuItems(context_menu_items)

        addDirectoryItem(plugin.handle, url, file_li)


@plugin.route("/display_picture/<info_hash>/<file_id>")
@query_arg("path")
def display_picture(info_hash, file_id, path):
    show_picture(api.get_stream_url(link=info_hash, path=path, file_id=file_id))


@plugin.route("/display_text/<info_hash>/<file_id>")
@query_arg("path")
def display_text(info_hash, file_id, path):
    r = requests.get(api.get_stream_url(link=info_hash, path=path, file_id=file_id))
    Dialog().textviewer(path, r.text)


@plugin.route("/play_url")
@query_arg("url")
@query_arg("poster", required=False)
@query_arg("title", required=False)
@query_arg("description", required=False)
@query_arg("category", required=False)
@query_arg("season", required=False)
@query_arg("episode", required=False)
@check_playable
def play_url(
    url, buffer=True, poster="", title="", description="", category="", season="", episode=""
):
    try:
        with requests.get(url, stream=True, timeout=30) as r:
            r.raise_for_status()
            info_hash = api.add_torrent_obj(
                r.raw, title=title, poster=poster, category=category or None
            )
            save_display_metadata(api._base_url, info_hash, title=title, plot=description, poster=poster)
    except requests.RequestException as e:
        raise PlayError("Failed to download torrent: {}".format(e))
    play_info_hash(
        info_hash=info_hash,
        buffer=buffer,
        title=title,
        description=description,
        season=season,
        episode=episode,
    )


@plugin.route("/play_magnet")
@query_arg("magnet")
@query_arg("poster", required=False)
@query_arg("title", required=False)
@query_arg("description", required=False)
@query_arg("category", required=False)
@query_arg("season", required=False)
@query_arg("episode", required=False)
@check_playable
def play_magnet(
    magnet, buffer=True, poster="", title="", description="", category="", season="", episode=""
):
    known_hash = _magnet_info_hash(magnet)
    if known_hash:
        save_display_metadata(
            api._base_url, known_hash, title=title, plot=description, poster=poster
        )
    info_hash = api.add_magnet(
        magnet, title=title, poster=poster, category=category or None
    )
    save_display_metadata(api._base_url, info_hash, title=title, plot=description, poster=poster)
    play_info_hash(
        info_hash=info_hash,
        buffer=buffer,
        title=title,
        description=description,
        season=season,
        episode=episode,
    )


@plugin.route("/play_path")
@query_arg("path")
@query_arg("poster", required=False)
@check_playable
def play_file(path, buffer=True, poster=""):
    info_hash = api.add_torrent(path, poster=poster)
    play_info_hash(info_hash=info_hash, buffer=buffer)


@plugin.route("/play_info_hash")
@query_arg("info_hash")
@query_arg("season", required=False)
@query_arg("episode", required=False)
@check_playable
def play_info_hash(info_hash, buffer=True, title="", description="", season="", episode=""):
    try:
        info = api.get_torrent_info(info_hash)
    except TorrServerError as e:
        notification(str(e))
        raise PlayError(str(e))

    if info.get("stat") == 1:
        wait_for_metadata(info_hash)

    files = info.get("file_stats")
    min_candidate_size = get_min_candidate_size() * 1024 * 1024
    candidate_files = [
        f
        for f in files
        if is_video(f.get("path")) and f.get("length") >= min_candidate_size
    ]
    if not candidate_files:
        notification(translate(30239))
        raise PlayError("No candidate files found for {}".format(info_hash))
    elif len(candidate_files) == 1:
        chosen_file = candidate_files[0]
    else:
        torrent_title = " ".join(
            str(info.get(key) or "") for key in ("title", "name")
        )
        chosen_file = match_episode_file(
            candidate_files,
            season=season,
            episode=episode,
            torrent_title=torrent_title,
        )
        if chosen_file is None:
            sort_files(candidate_files)
            display_names = strip_common_folder_prefix(candidate_files)
            chosen_index = Dialog().select(
                translate(30240), display_names
            )
            if chosen_index < 0:
                raise PlayError("User canceled dialog select")
            chosen_file = candidate_files[chosen_index]

    playback_metadata = {}
    if title or description:
        playback_metadata = {"title": title, "description": description}

    if buffer:
        buffer_and_play(
            info_hash=info_hash,
            file_id=chosen_file.get("id"),
            path=chosen_file.get("path"),
            **playback_metadata,
        )
    else:
        play(
            info_hash=info_hash,
            file_id=chosen_file.get("id"),
            path=chosen_file.get("path"),
            **playback_metadata,
        )


def wait_for_metadata(info_hash):
    close_busy_dialog()
    percent = 0
    timeout = get_metadata_timeout()
    start_time = time.time()
    monitor = Monitor()
    progress = DialogProgress()
    progress.create(ADDON_NAME, translate(30237))

    try:
        while True:
            try:
                info = api.get_torrent_info(info_hash)
            except TorrServerError as e:
                notification(str(e))
                raise PlayError(str(e))

            if info.get("stat") != 1:
                break

            if monitor.waitForAbort(0.5):
                raise PlayError("Abort requested")
            passed_time = time.time() - start_time
            if 0 < timeout:
                if timeout < passed_time:
                    notification(translate(30238))
                    raise PlayError("No metadata after timeout")
                percent = int(100 * passed_time / timeout)
            else:
                percent = 0 if percent == 100 else (percent + 5)
            progress.update(percent)
            if progress.iscanceled():
                raise CanceledError("User canceled metadata", info_hash, "")
    finally:
        progress.close()


@plugin.route("/buffer_and_play")
@query_arg("info_hash")
@query_arg("file_id")
@query_arg("path")
@check_playable
def buffer_and_play(info_hash, file_id, path, title="", description=""):
    preload_torrent(info_hash, file_id)
    try:
        info = api.get_torrent_info(info_hash)
    except TorrServerError as e:
        notification(str(e))
        raise PlayError(str(e))

    if info.get("stat") == 1:
        wait_for_metadata(info_hash)
    wait_for_buffering_completion(info_hash, file_id)
    poster = info.get("poster")
    play(
        info_hash=info_hash,
        file_id=file_id,
        path=path,
        poster=poster,
        title=title,
        description=description,
    )


def preload_torrent(info_hash, file_id):
    thread = Thread(target=api.preload_torrent, args=(info_hash, file_id))
    thread.start()


def wait_for_buffering_completion(info_hash, file_id):
    close_busy_dialog()
    monitor = Monitor()
    initial_retry_count = 0
    while True:
        try:
            info = api.get_torrent_file_info(info_hash, file_id)
            break
        except TorrServerError as e:
            retryable = is_retryable_error(e)
            if retryable and initial_retry_count < MAX_RETRIES_DEFAULT:
                initial_retry_count += 1
                backoff = backoff_seconds(initial_retry_count - 1)
                logging.warning(
                    "Initial buffering info error (retry %d/%d): %s, backing off %.1fs",
                    initial_retry_count,
                    MAX_RETRIES_DEFAULT,
                    e,
                    backoff,
                )
                if monitor.waitForAbort(backoff):
                    api.drop_torrent(info_hash)
                    raise PlayError("Abort requested")
                continue
            if retryable:
                logging.error(
                    "Initial buffering info error exhausted after %d retries: %s",
                    MAX_RETRIES_DEFAULT,
                    e,
                )
            notification(str(e))
            api.drop_torrent(info_hash)
            raise PlayError(str(e))

    of = translate(30244)
    timeout = get_buffering_timeout()
    retries = get_buffer_retries()
    retry_count = 0
    start_time = time.time()

    progress = DialogProgress()
    progress.create(ADDON_NAME)

    try:
        name = info.get("name", "")
        while True:
            current_time = time.time()
            try:
                status = api.get_torrent_file_info(info_hash, file_id)
            except TorrServerError as e:
                retryable = is_retryable_error(e)
                if retryable and retry_count < retries:
                    retry_count += 1
                    backoff = backoff_seconds(retry_count - 1)
                    logging.warning(
                        "Buffering polling error (retry %d/%d): %s, backing off %.1fs",
                        retry_count,
                        retries,
                        e,
                        backoff,
                    )
                    progress.update(
                        0,
                        "Retrying {}/{}...\n{}\n{}".format(
                            retry_count,
                            retries,
                            e,
                            name,
                        ),
                    )
                    if monitor.waitForAbort(backoff):
                        api.drop_torrent(info_hash)
                        raise PlayError("Abort requested")
                    continue
                if retryable:
                    logging.error(
                        "Buffering polling error exhausted after %d retries: %s",
                        retries,
                        e,
                    )
                notification(str(e))
                api.drop_torrent(info_hash)
                raise PlayError(str(e))

            retry_count = 0

            preloaded_bytes = status.get("preloaded_bytes", 0)
            preload_size = status.get("preload_size", 0)
            seeds = status.get("connected_seeders", 0)
            peers = status.get("active_peers", 0)
            total_peers = status.get("total_peers", 0)
            speed = status.get("download_speed", 0)
            name = status.get("name") or name

            if is_preload_complete(preloaded_bytes, preload_size):
                break

            buffering_progress = clamp_progress(
                compute_buffering_progress(preloaded_bytes, preload_size)
            )
            dialog_text = "{} - {:.2f}%\n{} {} {} - {}/s S:{} P:{}/{}\n{}\n".format(
                get_state_string(status.get("stat")),
                buffering_progress,
                sizeof_fmt(preloaded_bytes),
                of,
                sizeof_fmt(preload_size),
                sizeof_fmt(speed),
                seeds,
                peers,
                total_peers,
                name,
            )
            if is_resolving_metadata(preload_size):
                dialog_text = "Resolving metadata...\n" + dialog_text
                buffering_progress = 0

            progress.update(buffering_progress, dialog_text)

            if progress.iscanceled():
                api.drop_torrent(info_hash)
                raise CanceledError("User canceled buffering", info_hash, name)
            if 0 < timeout < current_time - start_time:
                notification(translate(30236))
                api.drop_torrent(info_hash)
                raise PlayError("Buffering timeout reached")
            if monitor.waitForAbort(1):
                api.drop_torrent(info_hash)
                raise PlayError("Abort requested")
    finally:
        progress.close()


@plugin.route("/play")
@query_arg("info_hash")
@query_arg("file_id")
@query_arg("path")
@query_arg("poster", required=False)
@check_playable
def play(info_hash, file_id, path, poster="", title="", description=""):
    name = path
    serve_url = api.get_stream_url(link=info_hash, path=name, file_id=file_id)
    item = ListItem(title or name, path=serve_url)
    if poster:
        item.setArt({"poster": poster})
    if title or description:
        set_info_tag(item, "video", {"title": title or name, "plot": description})

    # Prevent Kodi's synchronous pre-playback external-subtitle scan from opening
    # the TorrServer stream URL. Kodi's GetParentPath keeps the ?link=&index= query,
    # so the "directory" scan resolves to the media itself and stalls playback.
    # Workaround for xbmc/xbmc#28490 (regression from xbmc/xbmc#28275).
    item.setProperty("no-ext-subs-scan", "true")
    setResolvedUrl(plugin.handle, True, item)

    try:
        with JackTorrPlayer(
            text_handler=(
                (lambda: get_status_labels(info_hash) + (name,))
                if show_status_overlay()
                else None
            ),
            on_close_handler=lambda: handle_player_stop(info_hash, name=name),
        ) as player:
            player.handle_events(url=serve_url)
    except Exception as e:
        logging.error("Caught exception while playing file: %s", e, exc_info=True)


@plugin.route("/insert")
def dialog_insert():
    window = DialogInsert("DialogInsert.xml", ADDON_PATH, "Default")
    window.doModal()
    if window.type == DialogInsert.TYPE_URL:
        api.add_magnet(window.ret_val)
    elif window.type == DialogInsert.TYPE_PATH:
        api.add_torrent(window.ret_val)
    else:
        return
    notification(translate(30243), time=2000)


def run():
    try:
        plugin.run()
    except Exception as e:
        logging.error("Caught exception:", exc_info=True)
        notification(str(e))
