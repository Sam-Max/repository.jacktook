# Changelog

All notable changes to JackTorr are documented in this file.

## 1.2.2

### Added
- Torrent lists are organized by categories, including uncategorized torrents.
- Display titles, descriptions, and posters are retained for added torrents.

## 1.2.1

### Fixed
- TorrServer settings are now correctly gated by the apply-settings option in Kodi.

## 1.2.0

### Added
- Rutor search with persistent recent-search history.
- Poster and category actions for torrent items.
- A dedicated magnifying-glass icon for Search.

### Changed
- Torrent file lists now focus on playable files and remove shared folder prefixes.
- An optional setting can hide subfolder names in torrent file lists.
- Requested season episodes are selected automatically when available.
- Settings are organized more clearly and include additional localizations.

### Fixed
- Buffering retries transient failures and TorrServer connection and error handling is more resilient.
- TorrServer settings synchronization updates only explicitly enabled options.

## 1.1.0
Baseline release.
