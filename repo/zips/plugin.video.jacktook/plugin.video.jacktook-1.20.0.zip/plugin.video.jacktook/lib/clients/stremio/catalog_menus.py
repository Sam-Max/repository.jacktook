import json
import math
import os
import re
from collections.abc import Mapping
from dataclasses import asdict
from datetime import datetime, timedelta
from urllib.parse import quote

import xbmcgui
from xbmcplugin import addDirectoryItem, setContent

from lib.clients.stremio.helpers import (
    get_addon_by_base_url,
    get_addon_by_key,
    get_addon_display_name,
    get_catalog_display_name,
    get_selected_catalogs_addons,
    get_selected_tv_addons,
    merge_addons_lists,
)
from lib.clients.stremio.playback import (
    canonicalize_stremio_playback_payload,
    classify,
    current_stremio_playback_capabilities,
    normalize_stream,
    payload_from_torrent,
)
from lib.clients.tmdb.utils.utils import (
    add_tmdb_episode_context_menu,
    add_tmdb_movie_context_menu,
    add_tmdb_show_context_menu,
    tmdb_get,
)
from lib.db.cached import cache
from lib.db.pickle_db import PickleDatabase
from lib.utils.general.utils import (
    IndexerType,
    info_hash_to_magnet,
    truncate_text,
)
from lib.utils.kodi.settings import get_cache_expiration
from lib.utils.kodi.utils import (
    ADDON_HANDLE,
    ADDON_PATH,
    add_directory_items_batch,
    build_url,
    container_update,
    end_of_directory,
    is_youtube_addon_enabled,
    kodi_play_media,
    kodilog,
    make_list_item,
    notification,
    show_keyboard,
    translation,
)
from lib.utils.stremio.catalogs_utils import catalogs_get_cache

CATALOG_PAGE_SIZE = 25


def _safe_stremio_rating(value):
    if isinstance(value, bool):
        return 0.0

    try:
        rating = float(value)
    except (TypeError, ValueError):
        return 0.0

    return rating if math.isfinite(rating) else 0.0


def _stremio_search_history_key(params):
    return "stremio_search_catalog|{}|{}|{}".format(
        params.get("addon_key") or params.get("addon_url", ""),
        params.get("catalog_type", ""),
        params.get("catalog_id", ""),
    )


def _show_search_catalog_history(params):
    history_key = _stremio_search_history_key(params)
    list_item = make_list_item(label=translation(90006))
    list_item.setArt({"icon": os.path.join(ADDON_PATH, "resources", "img", "search.png")})
    addDirectoryItem(
        ADDON_HANDLE,
        build_url(
            "search_catalog",
            page=1,
            addon_url=params.get("addon_url", ""),
            catalog_type=params.get("catalog_type", ""),
            catalog_id=params.get("catalog_id", ""),
        ),
        list_item,
        isFolder=True,
    )

    for (text,) in cache.get_list(key=history_key):
        list_item = make_list_item(label=f"[I]{text}[/I]")
        list_item.setArt({"icon": os.path.join(ADDON_PATH, "resources", "img", "search.png")})
        addDirectoryItem(
            ADDON_HANDLE,
            build_url(
                "search_catalog",
                page=1,
                addon_url=params.get("addon_url", ""),
                catalog_type=params.get("catalog_type", ""),
                catalog_id=params.get("catalog_id", ""),
                query=text,
                is_keyboard=False,
            ),
            list_item,
            isFolder=True,
        )

    list_item = make_list_item(label=translation(90210))
    list_item.setArt({"icon": os.path.join(ADDON_PATH, "resources", "img", "clear.png")})
    addDirectoryItem(
        ADDON_HANDLE,
        build_url(
            "clear_stremio_search_history",
            addon_url=params.get("addon_url", ""),
            catalog_type=params.get("catalog_type", ""),
            catalog_id=params.get("catalog_id", ""),
        ),
        list_item,
        isFolder=True,
    )

    end_of_directory()


def clear_stremio_search_history(params):
    cache.clear_list(_stremio_search_history_key(params))
    _show_search_catalog_history(params)


def _build_stremio_ids(meta_id, tmdb_id="", imdb_id=""):
    return {
        "tmdb_id": tmdb_id or "",
        "tvdb_id": "",
        "imdb_id": imdb_id or "",
        "original_id": meta_id if ":" in str(meta_id or "") else "",
    }


def _build_stremio_meta_payload(
    *,
    name,
    meta_type,
    meta_id,
    tmdb_id="",
    imdb_id="",
    overview="",
    poster="",
    fanart="",
    genres=None,
    addon_url="",
    catalog_type="",
    meta_id_for_nav="",
    tv_data=None,
):
    return {
        "source": "stremio_catalog",
        "title": name,
        "overview": overview or "",
        "poster": poster or "",
        "fanart": fanart or poster or "",
        "genres": genres or [],
        "ids": _build_stremio_ids(meta_id, tmdb_id, imdb_id),
        "mode": "tv" if meta_type in ["series", "anime"] else "movies",
        "addon_url": addon_url,
        "catalog_type": catalog_type,
        "meta_id": meta_id_for_nav or meta_id,
        "tv_data": tv_data or {},
        "timestamp": datetime.now().strftime("%a, %d %b %Y %I:%M %p"),
    }


def _has_reliable_tmdb_ids(ids):
    return bool((ids or {}).get("tmdb_id"))


def _resolve_tmdb_ids_for_context_menu(ids, meta_type):
    if _has_reliable_tmdb_ids(ids):
        return ids

    imdb_id = (ids or {}).get("imdb_id")
    if not imdb_id:
        return ids

    result = cache.get(f"find_by_imdb_id|{imdb_id}")
    if not result:
        return ids

    resolved_tmdb_id = ""
    if meta_type == "movie":
        movie_results = getattr(result, "movie_results", []) or []
        if movie_results:
            resolved_tmdb_id = str(movie_results[0].get("id", ""))
    elif meta_type in ["series", "anime"]:
        tv_results = getattr(result, "tv_results", []) or []
        if tv_results:
            resolved_tmdb_id = str(tv_results[0].get("id", ""))

    if not resolved_tmdb_id:
        return ids

    resolved_ids = dict(ids or {})
    resolved_ids["tmdb_id"] = resolved_tmdb_id
    return resolved_ids


def _filter_tmdb_context_menu(context_menu):
    excluded_labels = {translation(90205), translation(90116)}
    return [item for item in context_menu if item[0] not in excluded_labels]


def _build_stremio_library_menu_item(payload):
    return (
        translation(90205),
        kodi_play_media(name="add_to_library", data=json.dumps(payload)),
    )


def _build_stremio_settings_menu_item():
    return (
        translation(90116),
        container_update(name="settings"),
    )


def _append_context_menu_items(list_item, context_menu):
    if not context_menu:
        return
    list_item.addContextMenuItems(context_menu, False)


def _param_truthy(value):
    return str(value).lower() in ("1", "true", "yes")


def _resolver_kwargs(addon_resolver):
    return {"resolver": addon_resolver} if addon_resolver is not None else {}


def _resolve_addon_params(params, addon_resolver=None):
    params = dict(params)
    if not params.get("addon_url") and params.get("addon_key"):
        addon = _get_catalog_addon_by_key(params["addon_key"], resolver=addon_resolver)
        if addon:
            params["addon_url"] = addon.url()
    return params


def _get_catalog_addon_by_key(addon_key, resolver=None):
    try:
        addon = get_addon_by_key(addon_key)
    except Exception:
        addon = None
    if addon is None and resolver is not None:
        try:
            addon = resolver("key", addon_key)
        except Exception:
            addon = None
    return addon


def _get_catalog_addon_by_base_url(addon_url, resolver=None):
    try:
        addon = get_addon_by_base_url(addon_url)
    except Exception:
        addon = None
    if addon is None and resolver is not None:
        try:
            addon = resolver("url", addon_url)
        except Exception:
            addon = None
    return addon


def _addon_route_reference(addon):
    try:
        return {"addon_key": addon.key()}
    except (AttributeError, TypeError):
        return {"addon_url": addon.url()}


def _get_stremio_catalogs(menu_type="", sub_menu_type="", extra_addons=None):
    if menu_type == "tv":
        stremio_addons = get_selected_tv_addons()
    else:
        stremio_addons = get_selected_catalogs_addons()
    if extra_addons:
        selected_addons = merge_addons_lists(stremio_addons, extra_addons)
    else:
        selected_addons = list(stremio_addons or [])

    if not selected_addons:
        kodilog(f"No addons found for menu_type={menu_type}")
        return []

    catalogs = []

    for addon in selected_addons:
        addon_types = addon.manifest.types

        if menu_type not in addon_types and not (menu_type == "tv" and "channel" in addon_types):
            continue

        for catalog in addon.manifest.catalogs:
            catalog_type = catalog.type
            target_type = sub_menu_type if sub_menu_type else menu_type

            # Allow 'anime' catalogs when target is 'series' and we are in 'anime' menu
            allowed_types = [target_type]
            if menu_type == "anime" and target_type == "series":
                allowed_types.append("anime")

            if target_type == "tv":
                allowed_types.append("channel")

            if target_type in ["movie", "series", "tv"] and catalog_type not in allowed_types:
                continue

            catalogs.append((addon, catalog))

    return catalogs


def list_stremio_catalogs(menu_type="", sub_menu_type="", extra_addons=None):
    catalogs = _get_stremio_catalogs(menu_type, sub_menu_type, extra_addons=extra_addons)
    search_items = []
    catalog_items = []

    genre_addon = next((addon for addon, catalog in catalogs if _catalog_genres(catalog)), None)
    if genre_addon:
        listitem = make_list_item(label="Genres")
        listitem.setArt({"icon": genre_addon.manifest.logo})
        genre_item = (
            build_url(
                action="list_catalog_genres",
                menu_type=menu_type,
                sub_menu_type=sub_menu_type,
            ),
            listitem,
            True,
        )

    for addon, catalog in catalogs:
        addon_name = get_addon_display_name(addon)
        catalog_name = get_catalog_display_name(addon, catalog)
        catalog_id = catalog.id
        catalog_type = catalog.type

        search_capabilities = any(extra.get("name") == "search" for extra in catalog.extra)

        if search_capabilities:
            listitem = make_list_item(label=f"{translation(90006)} {catalog_name}")
            listitem.setArt({"icon": addon.manifest.logo})

            search_items.append(
                (
                    build_url(
                        "search_catalog",
                        page=1,
                        **_addon_route_reference(addon),
                        catalog_type=catalog.type,
                        catalog_id=catalog_id,
                        menu_type=menu_type,
                        sub_menu_type=sub_menu_type,
                        has_meta_resource=_addon_has_resource(addon, "meta", catalog_type),
                        has_stream_resource=_addon_has_resource(addon, "stream", catalog_type),
                    ),
                    listitem,
                    True,
                )
            )

        if catalog_name or catalog_id:
            if addon.manifest.name == "Cinemeta":
                label = f"{addon_name} - {catalog_name or catalog_id}"
            else:
                label = catalog_name or catalog_id

            listitem = make_list_item(label=label)
            listitem.setArt({"icon": addon.manifest.logo})

            catalog_items.append(
                (
                    build_url(
                        action="list_catalog",
                        **_addon_route_reference(addon),
                        menu_type=menu_type,
                        sub_menu_type=sub_menu_type,
                        catalog_type=catalog.type,
                        catalog_id=catalog.id,
                    ),
                    listitem,
                    True,
                )
            )

    directory_items = search_items
    if genre_addon:
        directory_items.append(genre_item)
    directory_items.extend(catalog_items)
    add_directory_items_batch(directory_items)


def _get_manifest_catalog(addon_url, catalog_type, catalog_id, addon_key="", resolver=None):
    try:
        addon = (
            _get_catalog_addon_by_key(addon_key, resolver=resolver)
            if addon_key
            else _get_catalog_addon_by_base_url(addon_url, resolver=resolver)
        )
    except Exception:
        return None
    if not addon:
        return None

    for catalog in addon.manifest.catalogs:
        if catalog.type == catalog_type and catalog.id == catalog_id:
            return catalog

    return None


def _catalog_genres(catalog):
    for extra in catalog.extra:
        if extra.get("name") == "genre" and extra.get("options"):
            return extra["options"]
    return []


def list_catalog_genres(params, addon_resolver=None, extra_addons=None):
    directory_items = []
    seen_genres = set()
    for addon, catalog in _get_stremio_catalogs(
        params["menu_type"], params.get("sub_menu_type", ""), extra_addons=extra_addons
    ):
        for genre in _catalog_genres(catalog):
            genre_key = genre.casefold()
            if genre_key in seen_genres:
                continue
            seen_genres.add(genre_key)

            listitem = make_list_item(label=genre)
            listitem.setArt({"icon": addon.manifest.logo})
            directory_items.append(
                (
                    build_url(
                        action="list_catalog",
                        **_addon_route_reference(addon),
                        menu_type=params["menu_type"],
                        sub_menu_type=params.get("sub_menu_type", ""),
                        catalog_type=catalog.type,
                        catalog_id=catalog.id,
                        genre=genre,
                    ),
                    listitem,
                    True,
                )
            )

    add_directory_items_batch(directory_items)
    end_of_directory()


def _extra_display_name(extra):
    """Pick a friendly dialog title for a catalog extra.

    Cinemeta's "New" catalog reuses the ``genre`` extra with year values, so
    an all-numeric 4-digit option list reads as years, not genres.
    """
    name = extra.get("name") or ""
    options = [str(option) for option in (extra.get("options") or [])]
    if (
        name.casefold() == "genre"
        and options
        and all(re.fullmatch(r"\d{4}", option) for option in options)
    ):
        return translation(90027)  # "Years"
    return name


def _is_no_filter_options(options):
    """Return True when every option is a no-op placeholder ("None", blank)."""
    return bool(options) and all(
        str(option).strip().casefold() == "none" or not str(option).strip() for option in options
    )


def _catalog_supports_extra(
    addon_url, catalog_type, catalog_id, extra_name, addon_key="", resolver=None
):
    catalog = _get_manifest_catalog(
        addon_url, catalog_type, catalog_id, addon_key, **_resolver_kwargs(resolver)
    )
    if not catalog:
        return False

    return any(extra.get("name") == extra_name for extra in (catalog.extra or []))


def _catalog_extra_names(addon_url, catalog_type, catalog_id, addon_key="", resolver=None):
    try:
        catalog = _get_manifest_catalog(
            addon_url, catalog_type, catalog_id, addon_key, **_resolver_kwargs(resolver)
        )
    except Exception:
        return set()
    if not catalog:
        return set()
    return {extra.get("name") for extra in catalog.extra if extra.get("name")}


def list_catalog(params, addon_resolver=None):
    params = _resolve_addon_params(params, addon_resolver=addon_resolver)
    if not params.get("addon_url"):
        end_of_directory()
        return
    content_type = "movies" if params["menu_type"] == "movie" else "tvshows"
    setContent(ADDON_HANDLE, content_type)

    skip = int(params.get("skip", 0))

    declared_extras = _catalog_extra_names(
        params["addon_url"],
        params["catalog_type"],
        params["catalog_id"],
        params.get("addon_key", ""),
        **_resolver_kwargs(addon_resolver),
    )
    extras = {
        key: params[key]
        for key in declared_extras.union({"genre", "search"})
        if params.get(key) not in (None, "")
    }
    catalog = _get_manifest_catalog(
        params["addon_url"],
        params["catalog_type"],
        params["catalog_id"],
        params.get("addon_key", ""),
        **_resolver_kwargs(addon_resolver),
    )
    if catalog:
        for extra in catalog.extra:
            name = extra.get("name")
            if not name or name in extras or name == "skip":
                continue
            if not extra.get("isRequired"):
                continue
            options = list(extra.get("options") or [])
            limit = extra.get("optionsLimit")
            if isinstance(limit, int) and limit >= 0:
                options = options[:limit]
            if _is_no_filter_options(options):
                # Nothing meaningful to choose (e.g. Bingecat "None"); request
                # the catalog without this extra instead of prompting.
                continue
            if options:
                selected = xbmcgui.Dialog().select(_extra_display_name(extra), options)
                if selected < 0:
                    end_of_directory()
                    return
                extras[name] = options[selected]
            else:
                kodilog(f"Stremio catalog skipped: missing required extra '{name}'")
                notification(f"This catalog requires {name}.")
                end_of_directory()
                return

    supports_skip = _catalog_supports_extra(
        params["addon_url"],
        params["catalog_type"],
        params["catalog_id"],
        "skip",
        params.get("addon_key", ""),
        **_resolver_kwargs(addon_resolver),
    )

    request_kwargs = dict(extras)
    if supports_skip and skip:
        request_kwargs["skip"] = skip

    response = catalogs_get_cache("list_catalog", params, **request_kwargs)
    if not response:
        end_of_directory()
        return

    metas = response.get("metas", [])
    total_metas = len(metas)

    if not supports_skip:
        metas = metas[skip : skip + CATALOG_PAGE_SIZE]

    if not metas:
        notification(translation(90516))
        end_of_directory()
        return

    add_meta_items(metas, params, **_resolver_kwargs(addon_resolver))

    has_next_page = False
    if supports_skip:
        has_next_page = len(metas) >= CATALOG_PAGE_SIZE
    else:
        has_next_page = total_metas > skip + len(metas)

    if has_next_page:
        next_page_params = {
            "menu_type": params["menu_type"],
            "sub_menu_type": params.get("sub_menu_type", ""),
            "catalog_type": params["catalog_type"],
            "catalog_id": params["catalog_id"],
            "skip": skip + len(metas),
        }
        if params.get("genre") not in (None, ""):
            next_page_params["genre"] = params["genre"]
        for key, value in extras.items():
            if value not in (None, ""):
                next_page_params[key] = value
        if params.get("addon_key"):
            next_page_params["addon_key"] = params["addon_key"]
        else:
            next_page_params["addon_url"] = params["addon_url"]
        next_url = build_url("list_catalog", **next_page_params)
        list_item = make_list_item(label=translation(90515))
        addDirectoryItem(handle=ADDON_HANDLE, url=next_url, listitem=list_item, isFolder=True)

    end_of_directory()


def search_catalog(params, addon_resolver=None):
    params = _resolve_addon_params(params, addon_resolver=addon_resolver)
    if not params.get("addon_url"):
        return
    page = int(params["page"])
    pickle_db = PickleDatabase()
    history_key = _stremio_search_history_key(params)

    if "menu_type" not in params:
        params = dict(params)
        params["menu_type"] = params.get("catalog_type", "movie")
    if "sub_menu_type" not in params:
        params["sub_menu_type"] = ""

    if page == 1:
        if str(params.get("is_keyboard", "True")).lower() in ("false", "0", "no"):
            query = params.get("query", "")
        else:
            query = show_keyboard(id=30241, default=params.get("query", ""))
            if not query:
                _show_search_catalog_history(params)
                return
            cache.add_to_list(
                key=history_key,
                item=(query,),
                expires=timedelta(hours=get_cache_expiration()),
            )
        pickle_db.set_key("search_catalog_query", query)
    else:
        query = params.get("query") or pickle_db.get_key("search_catalog_query")

    declared_extras = _catalog_extra_names(
        params["addon_url"],
        params["catalog_type"],
        params["catalog_id"],
        params.get("addon_key", ""),
        **_resolver_kwargs(addon_resolver),
    )
    request_extras = {
        key: params[key] for key in declared_extras if params.get(key) not in (None, "")
    }
    request_extras["search"] = query
    catalog = _get_manifest_catalog(
        params["addon_url"],
        params["catalog_type"],
        params["catalog_id"],
        params.get("addon_key", ""),
        **_resolver_kwargs(addon_resolver),
    )
    if catalog:
        for extra in catalog.extra:
            name = extra.get("name")
            if not extra.get("isRequired") or name in request_extras or name == "skip":
                continue
            options = list(extra.get("options") or [])
            limit = extra.get("optionsLimit")
            if isinstance(limit, int) and limit >= 0:
                options = options[:limit]
            if _is_no_filter_options(options):
                # Nothing meaningful to choose (e.g. Bingecat "None").
                continue
            if not options:
                kodilog(f"Stremio catalog search skipped: missing required extra '{name}'")
                return
            selected = xbmcgui.Dialog().select(_extra_display_name(extra), options)
            if selected < 0:
                return
            request_extras[name] = options[selected]
    supports_skip = "skip" in declared_extras
    skip = (page - 1) * CATALOG_PAGE_SIZE
    if supports_skip and skip:
        request_extras["skip"] = skip
    response = catalogs_get_cache("list_catalog", params, **request_extras)
    if not response:
        return

    metas = response.get("metas", [])
    if not supports_skip:
        metas = metas[skip : skip + CATALOG_PAGE_SIZE]
    add_meta_items(metas, params, **_resolver_kwargs(addon_resolver))

    if len(metas) >= CATALOG_PAGE_SIZE:
        next_params = {
            key: value
            for key, value in params.items()
            if key not in {"addon_url", "page", "is_keyboard"}
        }
        if not next_params.get("addon_key"):
            next_params["addon_url"] = params["addon_url"]
        next_params.update({"page": page + 1, "query": query, "is_keyboard": False})
        next_params.update(
            {key: value for key, value in request_extras.items() if key not in {"search", "skip"}}
        )
        addDirectoryItem(
            ADDON_HANDLE,
            build_url("search_catalog", **next_params),
            make_list_item(label=translation(90515)),
            isFolder=True,
        )
    end_of_directory()


def _addon_has_resource(addon, resource_name, content_type):
    if not addon:
        return False
    for resource in addon.manifest.resources:
        if resource.name == resource_name and content_type in resource.types:
            return True
    return False


def addon_has_meta(addon_url, content_type, addon=None, resolver=None):
    """Check if the addon serves its own meta (seasons/episodes) for the given type."""
    addon = addon or _get_catalog_addon_by_base_url(addon_url, resolver=resolver)
    return _addon_has_resource(addon, "meta", content_type)


def addon_has_stream(addon_url, content_type, addon=None, resolver=None):
    """Check if the addon serves its own streams for the given type."""
    addon = addon or _get_catalog_addon_by_base_url(addon_url, resolver=resolver)
    return _addon_has_resource(addon, "stream", content_type)


def add_meta_items(metas, params, resolver=None):
    catalog_type = params["catalog_type"]
    menu_type = params.get("menu_type", catalog_type)
    sub_menu_type = params.get("sub_menu_type", "")
    addon_url = params["addon_url"]

    content_type = "movies" if menu_type == "movie" else "tvshows"
    setContent(ADDON_HANDLE, content_type)

    def should_include(meta):
        meta_type = meta.type
        if menu_type in ["anime", "movie"] and sub_menu_type == "movie":
            return meta_type == "movie"
        if menu_type in ["anime", "series"] and sub_menu_type == "series":
            return meta_type in ["series", "anime"]
        if menu_type == "tv":
            return meta_type in ["tv", "channel"]
        return True

    metas = [m for m in metas if should_include(m)]
    if not metas:
        notification(f"{translation(90511)} {menu_type}")
        end_of_directory()
        return

    addon = None
    has_meta_resource = _param_truthy(params.get("has_meta_resource"))
    has_stream_resource = _param_truthy(params.get("has_stream_resource"))
    if not has_meta_resource and not has_stream_resource:
        addon = _get_catalog_addon_by_base_url(addon_url, resolver=resolver)
        has_meta_resource = addon_has_meta(addon_url, catalog_type, addon=addon, resolver=resolver)
        has_stream_resource = addon_has_stream(
            addon_url, catalog_type, addon=addon, resolver=resolver
        )

    for meta in metas:
        name = meta.name or ""
        meta_type = meta.type or ""
        meta_id = meta.id or ""
        tmdb_id = meta.moviedb_id or ""
        imdb_id = meta.imdb_id or ""

        if "tmdb" in meta_id:
            tmdb_id = meta_id.split(":")[1]
        elif meta_id.startswith("tt"):
            imdb_id = meta_id
            tmdb_id = ""

        ids = _build_stremio_ids(meta_id, tmdb_id, imdb_id)
        poster = meta.poster or ""
        background = meta.background or ""
        library_payload = _build_stremio_meta_payload(
            name=name,
            meta_type=meta_type,
            meta_id=meta_id,
            tmdb_id=tmdb_id,
            imdb_id=imdb_id,
            overview=meta.description or "",
            poster=poster,
            fanart=background,
            genres=meta.genres,
            addon_url=addon_url,
            catalog_type=catalog_type,
            meta_id_for_nav=meta_id,
        )

        if meta_type == "series":
            if has_meta_resource:
                url = build_url(
                    "list_stremio_seasons",
                    addon_url=addon_url,
                    catalog_type=catalog_type,
                    meta_id=meta_id,
                )
            elif tmdb_id or imdb_id:
                url = build_url("show_seasons_details", ids=ids, mode="tv", media_type="tv")
            else:
                url = build_url(
                    "list_stremio_seasons",
                    addon_url=addon_url,
                    catalog_type=catalog_type,
                    meta_id=meta_id,
                )
        elif meta_type == "movie":
            if has_stream_resource:
                is_custom_movie = True
                url = build_url(
                    "list_stremio_movie",
                    addon_url=addon_url,
                    catalog_type=catalog_type,
                    meta_id=meta_id,
                    ids=json.dumps(ids),
                    title=name,
                    overview=meta.description or "",
                    poster=poster,
                    fanart=background,
                    genres=json.dumps(meta.genres or []),
                )
            elif tmdb_id or imdb_id or ":" in meta_id:
                is_custom_movie = False
                url = build_url("search", mode="movies", query=name, ids=ids)
            else:
                is_custom_movie = True
                url = build_url(
                    "list_stremio_movie",
                    addon_url=addon_url,
                    catalog_type=catalog_type,
                    meta_id=meta_id,
                    ids=json.dumps(ids),
                    title=name,
                    overview=meta.description or "",
                    poster=poster,
                    fanart=background,
                    genres=json.dumps(meta.genres or []),
                )
        elif meta_type in ["tv", "channel"]:
            if meta.streams:
                streams_data = [asdict(s) for s in meta.streams]
                url = build_url(
                    "list_stremio_tv_streams",
                    streams=json.dumps(streams_data),
                    ids=json.dumps(ids),
                    title=name,
                    overview=meta.description or "",
                    poster=poster,
                    fanart=background,
                    genres=json.dumps(meta.genres or []),
                    addon_url=addon_url,
                    catalog_type=catalog_type,
                    meta_id=meta_id,
                )
            else:
                url = build_url(
                    "list_stremio_tv",
                    addon_url=addon_url,
                    catalog_type=catalog_type,
                    meta_id=meta_id,
                    ids=json.dumps(ids),
                    title=name,
                    overview=meta.description or "",
                    poster=poster,
                    fanart=background,
                    genres=json.dumps(meta.genres or []),
                )
        else:
            continue

        list_item = make_list_item(label=name)
        info_tag = list_item.getVideoInfoTag()
        info_tag.setUniqueID(meta_id, type="imdb" if meta_id.startswith("tt") else "mf")
        info_tag.setTitle(name)
        info_tag.setPlot(truncate_text(meta.description or ""))
        info_tag.setGenres(meta.genres)
        info_tag.setMediaType("video")

        is_folder = meta_type != "movie" or (meta_type == "movie" and is_custom_movie)
        if not is_folder:
            list_item.setProperty("IsPlayable", "true")

        list_item.setArt(
            {
                "thumb": poster,
                "poster": poster,
                "fanart": poster,
                "icon": poster,
                "banner": background,
                "landscape": background,
            }
        )

        context_menu_ids = _resolve_tmdb_ids_for_context_menu(ids, meta_type)

        context_menu = [
            _build_stremio_library_menu_item(library_payload),
            _build_stremio_settings_menu_item(),
        ]
        if _has_reliable_tmdb_ids(context_menu_ids):
            if meta_type == "movie":
                context_menu.extend(
                    _filter_tmdb_context_menu(
                        add_tmdb_movie_context_menu(
                            mode="movies",
                            media_type="movie",
                            title=name,
                            ids=context_menu_ids,
                        )
                    )
                )
            elif meta_type in ["series", "anime"]:
                context_menu.extend(
                    _filter_tmdb_context_menu(
                        add_tmdb_show_context_menu(mode="tv", ids=context_menu_ids, title=name)
                    )
                )

        _append_context_menu_items(list_item, context_menu)

        addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)


def list_stremio_seasons(params, addon_resolver=None):
    params = _resolve_addon_params(params, addon_resolver=addon_resolver)
    kodilog("list_stremio_seasons")
    response = catalogs_get_cache("list_stremio_seasons", params)
    if not response:
        return

    meta_data = response.get("meta")
    if not meta_data:
        notification(translation(90517))
        return

    videos = meta_data.videos
    if not videos:
        notification(translation(90517))
        return

    available_seasons = set(
        int(video.imdbSeason) if video.imdbSeason else int(video.season) for video in videos
    )
    items = []
    for season in available_seasons:
        url = build_url(
            "list_stremio_episodes",
            addon_url=params["addon_url"],
            catalog_type=params["catalog_type"],
            meta_id=params["meta_id"],
            season=season,
        )
        list_item = make_list_item(label=f"{translation(90512)} {season}")
        info_tag = list_item.getVideoInfoTag()
        info_tag.setUniqueID(meta_data.id, type="imdb" if meta_data.id.startswith("tt") else "mf")
        info_tag.setTitle(meta_data.name)
        info_tag.setPlot(truncate_text(meta_data.description or ""))
        info_tag.setRating(_safe_stremio_rating(meta_data.imdbRating))
        info_tag.setGenres(meta_data.genres)
        info_tag.setTvShowTitle(meta_data.name)
        info_tag.setSeason(season)

        list_item.setArt(
            {
                "thumb": meta_data.poster or "",
                "poster": meta_data.poster or "",
                "fanart": meta_data.poster or "",
                "icon": meta_data.poster or "",
                "banner": meta_data.background or "",
                "landscape": meta_data.background or "",
            }
        )

        items.append((url, list_item, True))
    add_directory_items_batch(items)
    end_of_directory()


def list_stremio_episodes(params, addon_resolver=None):
    params = _resolve_addon_params(params, addon_resolver=addon_resolver)
    kodilog("list_stremio_episodes")
    response = catalogs_get_cache("list_stremio_episodes", params)
    if not response:
        return

    meta_data = response.get("meta")
    if not meta_data:
        notification(translation(90510))
        return

    videos = meta_data.videos
    if not videos:
        notification(translation(90513))
        return

    # Resolve IDs once for the show
    tmdb_id = ""
    imdb_id = ""
    # Store original ID (e.g. kitsu:123) for addons that support it
    original_id = meta_data.id if ":" in meta_data.id else ""

    if meta_data.imdb_id:
        imdb_id = meta_data.imdb_id
        res = tmdb_get("find_by_imdb_id", imdb_id)
        if getattr(res, "tv_results", []):
            tmdb_id = str(res.tv_results[0]["id"])

    if not tmdb_id and not imdb_id and meta_data.name:
        kodilog(f"No IDs found for {meta_data.name}. Searching TMDB...")
        year = meta_data.releaseInfo.split("-")[0] if meta_data.releaseInfo else ""
        results = tmdb_get("search_tv", {"query": meta_data.name, "page": 1, "year": year})
        if results and results.results:
            try:
                tmdb_id = str(results.results[0].id)
                kodilog(f"Fallback found TMDB ID: {tmdb_id} for {meta_data.name}")
            except Exception:
                pass

    if tmdb_id and not imdb_id:
        details = tmdb_get("tv_details", tmdb_id)
        if details and getattr(details, "external_ids", None):
            imdb_id = details.external_ids.get("imdb_id", "")
            kodilog(f"Resolved IMDB ID: {imdb_id} from TMDB ID: {tmdb_id}")

    default_video_id = getattr(getattr(meta_data, "behaviorHints", None), "defaultVideoId", None)
    if default_video_id:
        videos = sorted(videos, key=lambda video: video.id != default_video_id)

    addon = _get_catalog_addon_by_base_url(params["addon_url"], resolver=addon_resolver)
    has_stream_resource = addon_has_stream(
        params["addon_url"], params["catalog_type"], addon=addon, resolver=addon_resolver
    )
    items = []
    for video in videos:
        try:
            season = int(video.imdbSeason) if video.imdbSeason else int(video.season)
            episode = int(video.imdbEpisode) if video.imdbEpisode else int(video.episode)
        except (ValueError, TypeError):
            continue

        if season != int(params["season"]):
            continue

        title = video.title or getattr(video, "name", "") or meta_data.name

        tv_data = {
            "name": quote(title),
            "episode": episode,
            "season": season,
        }

        ids = {
            "tmdb_id": tmdb_id,
            "tvdb_id": "",
            "imdb_id": imdb_id,
            "original_id": original_id,
        }

        preferred_stremio_streams = [asdict(stream) for stream in video.streams]
        scoped_addon_url = (
            ""
            if preferred_stremio_streams
            else (params["addon_url"] if has_stream_resource else "")
        )

        url = build_url(
            "search",
            mode="tv",
            media_type="tv",
            query=meta_data.name,
            ids=ids,
            tv_data=tv_data,
            preferred_stremio_streams=json.dumps(preferred_stremio_streams),
            scoped_addon_url=scoped_addon_url,
            stremio_addon_url=params["addon_url"],
            stremio_catalog_type=params["catalog_type"],
            stremio_meta_id=params["meta_id"],
        )

        list_item = make_list_item(label=f"{season}x{episode}. {title}")
        info_tag = list_item.getVideoInfoTag()
        info_tag.setUniqueID(meta_data.id, type="imdb" if meta_data.id.startswith("tt") else "mf")
        info_tag.setTitle(title)
        info_tag.setPlot(truncate_text(video.overview or ""))
        info_tag.setRating(_safe_stremio_rating(meta_data.imdbRating))
        info_tag.setGenres(meta_data.genres)
        info_tag.setTvShowTitle(title)
        info_tag.setSeason(season)
        info_tag.setEpisode(episode)

        list_item.setProperty("IsPlayable", "true")

        context_menu = [
            _build_stremio_library_menu_item(
                _build_stremio_meta_payload(
                    name=meta_data.name,
                    meta_type="series",
                    meta_id=meta_data.id,
                    tmdb_id=tmdb_id,
                    imdb_id=imdb_id,
                    overview=meta_data.description or video.overview or "",
                    poster=meta_data.poster or video.thumbnail or "",
                    fanart=meta_data.background or meta_data.poster or video.thumbnail or "",
                    genres=meta_data.genres,
                    addon_url=params["addon_url"],
                    catalog_type=params["catalog_type"],
                    meta_id_for_nav=params["meta_id"],
                    tv_data=tv_data,
                )
            ),
            _build_stremio_settings_menu_item(),
        ]
        context_menu_ids = _resolve_tmdb_ids_for_context_menu(ids, "series")
        if _has_reliable_tmdb_ids(context_menu_ids):
            context_menu = (
                _filter_tmdb_context_menu(
                    add_tmdb_episode_context_menu(
                        mode="tv",
                        tv_name=meta_data.name,
                        tv_data=tv_data,
                        ids=context_menu_ids,
                    )
                )
                + context_menu
            )
        else:
            context_menu.insert(
                0,
                (
                    translation(90049),
                    kodi_play_media(
                        name="search",
                        mode="tv",
                        media_type="tv",
                        query=meta_data.name,
                        ids=ids,
                        tv_data=tv_data,
                        preferred_stremio_streams=json.dumps(preferred_stremio_streams),
                        scoped_addon_url=scoped_addon_url,
                        stremio_addon_url=params["addon_url"],
                        stremio_catalog_type=params["catalog_type"],
                        stremio_meta_id=params["meta_id"],
                        rescrape=True,
                    ),
                ),
            )
        _append_context_menu_items(list_item, context_menu)

        list_item.setArt(
            {
                "thumb": meta_data.poster or "",
                "poster": meta_data.poster or "",
                "fanart": meta_data.poster or "",
                "icon": meta_data.poster or "",
                "banner": meta_data.background or "",
                "landscape": meta_data.background or "",
            }
        )

        items.append((url, list_item, False))

    add_directory_items_batch(items)
    end_of_directory()


def _stremio_catalog_streams(response):
    if isinstance(response, Mapping):
        streams = response.get("streams", [])
    else:
        streams = getattr(response, "streams", [])
    return streams if isinstance(streams, (list, tuple)) else []


def _stremio_catalog_param(params, key, default):
    value = params.get(key, default)
    if isinstance(value, type(default)):
        return value
    if not isinstance(value, str):
        return default
    try:
        parsed = json.loads(value or "")
    except (TypeError, ValueError):
        return default
    return parsed if isinstance(parsed, type(default)) else default


def _has_positive_int_id(ids, key):
    ids = ids if isinstance(ids, Mapping) else {}
    value = ids.get(key)
    if isinstance(value, str):
        value = value.strip()
        if not value.isascii() or not value.isdigit():
            return False
        try:
            return int(value) > 0
        except (TypeError, ValueError):
            return False
    if isinstance(value, bool):
        return False
    return isinstance(value, int) and value > 0


def _resolve_stremio_catalog_tmdb_id(ids):
    """Resolve a TMDB id for movie catalog playback without guessing by title."""
    ids = ids if isinstance(ids, Mapping) else {}
    if _has_positive_int_id(ids, "tmdb_id"):
        return str(ids.get("tmdb_id")).strip()

    imdb_id = ids.get("imdb_id")
    if not isinstance(imdb_id, str) or not imdb_id.startswith("tt"):
        return ""

    res = tmdb_get("find_by_imdb_id", imdb_id)
    movie_results = getattr(res, "movie_results", [])
    if movie_results:
        tmdb_id = movie_results[0].get("id", "")
        if _has_positive_int_id({"tmdb_id": tmdb_id}, "tmdb_id"):
            return str(tmdb_id).strip()

    return ""


def _apply_stremio_catalog_tracking_identity(playback_data, params):
    """Give movie catalog stream payloads a canonical tracking identity.

    The player only records progress/scrobbles when the payload carries
    ``mode == "movies"`` plus a positive integer ``tmdb_id``.
    """
    if params.get("media_kind") != "movie":
        return

    meta_id = str(playback_data.get("meta_id") or "")
    if meta_id.startswith(("movie:placeholder-", "tv:placeholder-")):
        return

    ids = playback_data.get("ids")
    tmdb_id = _resolve_stremio_catalog_tmdb_id(ids)
    if not tmdb_id:
        return

    playback_data["mode"] = "movies"
    resolved_ids = dict(ids) if isinstance(ids, Mapping) else {}
    resolved_ids["tmdb_id"] = tmdb_id
    playback_data["ids"] = resolved_ids


def _stremio_catalog_source(stream):
    if isinstance(stream, Mapping):
        return stream
    try:
        if vars(stream):
            return stream
    except (TypeError, ValueError):
        pass

    fields = (
        "url",
        "ytId",
        "infoHash",
        "fileIdx",
        "externalUrl",
        "name",
        "title",
        "description",
        "behaviorHints",
        "subtitles",
        "fileMustInclude",
        "nzbUrl",
        "rarUrls",
        "zipUrls",
        "sevenZipUrls",
        "tgzUrls",
        "tarUrls",
        "meta",
        "sources",
        "trackers",
        "stremioMetadata",
        "stremio_metadata",
    )
    source = {}
    for field in fields:
        try:
            value = getattr(stream, field, None)
        except Exception:
            continue
        if value is not None:
            source[field] = value
    return source


def _stremio_catalog_playback_data(stream, params):
    try:
        source = canonicalize_stremio_playback_payload(_stremio_catalog_source(stream))
        candidate = normalize_stream(source, origin="catalog")
        payload = payload_from_torrent(source)
        decision = classify(
            candidate,
            current_stremio_playback_capabilities(),
        )
        if not decision.supported:
            return None
    except (TypeError, ValueError):
        return None

    playback_data = {
        "mode": "movie",
        "source": "stremio_catalog",
        "title": candidate.title or candidate.name or candidate.filename or params.get("title", ""),
        "overview": candidate.description or params.get("overview", ""),
        "poster": params.get("poster", ""),
        "fanart": params.get("fanart", params.get("poster", "")),
        "genres": _stremio_catalog_param(params, "genres", []),
        "ids": _stremio_catalog_param(params, "ids", {}),
        "addon_url": params.get("addon_url", ""),
        "catalog_type": params.get("catalog_type", ""),
        "meta_id": params.get("meta_id", ""),
    }

    # Tracking identity (scrobble / continue-watching / progress): catalog
    _apply_stremio_catalog_tracking_identity(playback_data, params)

    if params.get("catalog_type") == "channel":
        playback_data["is_live_tv"] = True
    elif isinstance(playback_data["meta_id"], str) and playback_data["meta_id"].startswith(
        ("movie:placeholder-", "tv:placeholder-")
    ):
        playback_data["is_informational_placeholder"] = True

    for key in ("type", "debrid_type", "indexer", "is_pack"):
        value = payload.get(key)
        if value not in (None, "", False, [], {}):
            playback_data[key] = value

    candidate_values = {
        "url": candidate.url,
        "info_hash": candidate.infoHash,
        "file_idx": candidate.fileIdx,
        "sources": list(candidate.sources),
        "trackers": list(candidate.trackers),
        "headers": dict(candidate.headers),
        "filename": candidate.filename,
        "size": candidate.size,
        "videoHash": candidate.videoHash,
        "ytId": candidate.ytId,
        "externalUrl": candidate.externalUrl,
        "stream_subtitles": list(candidate.subtitles),
        "subtitles": list(candidate.subtitles),
    }
    for key, value in candidate_values.items():
        if value is not None and value not in ("", [], {}):
            playback_data[key] = value

    canonical_metadata = payload.get("stremio_metadata")
    if isinstance(canonical_metadata, Mapping) and any(canonical_metadata.values()):
        playback_data["stremio_metadata"] = dict(canonical_metadata)

    if decision.source_class == "youtube":
        if not is_youtube_addon_enabled():
            return None
        playback_data["url"] = (
            f"plugin://plugin.video.youtube/play/?video_id={quote(candidate.ytId or '', safe='')}"
        )

    if decision.source_class == "direct_http":
        playback_data["type"] = IndexerType.DIRECT
    elif decision.source_class == "torrent_hash":
        playback_data["is_torrent"] = True
        playback_data["magnet"] = (
            candidate.url
            if candidate.url and candidate.url.lower().startswith("magnet:")
            else info_hash_to_magnet(candidate.infoHash or "")
        )

    return playback_data, candidate


def list_stremio_movie(params, addon_resolver=None):
    params = _resolve_addon_params(params, addon_resolver=addon_resolver)
    params["media_kind"] = "movie"
    response = catalogs_get_cache("list_stremio_movie", params)
    if not response:
        return

    streams = _stremio_catalog_streams(response)
    if not streams:
        notification(translation(90514))
        return

    items = []
    for stream in streams:
        prepared = _stremio_catalog_playback_data(stream, params)
        if not prepared:
            continue
        playback_data, candidate = prepared

        url = build_url(
            "play_media",
            data=json.dumps(playback_data),
        )

        list_item = make_list_item(label=playback_data["title"])
        list_item.setProperty("IsPlayable", "true")
        info_tag = list_item.getVideoInfoTag()
        info_tag.setPlot(truncate_text(candidate.description or ""))

        items.append((url, list_item, False))
    add_directory_items_batch(items)
    end_of_directory()


def list_stremio_tv(params, addon_resolver=None):
    params = _resolve_addon_params(params, addon_resolver=addon_resolver)
    response = catalogs_get_cache("list_stremio_tv", params)
    if not response:
        end_of_directory()
        return

    streams = _stremio_catalog_streams(response)
    if not streams:
        notification(translation(90514))
        end_of_directory()
        return

    items = []
    for stream in streams:
        prepared = _stremio_catalog_playback_data(stream, params)
        if not prepared:
            continue
        playback_data, candidate = prepared
        url = build_url(
            "play_media",
            data=json.dumps(playback_data),
        )

        list_item = make_list_item(label=playback_data["title"])
        list_item.setProperty("IsPlayable", "true")
        info_tag = list_item.getVideoInfoTag()
        info_tag.setPlot(truncate_text(candidate.description or ""))

        items.append((url, list_item, False))
    add_directory_items_batch(items)
    end_of_directory()


def list_stremio_tv_streams(params):
    raw_streams = params.get("streams", [])
    if isinstance(raw_streams, str):
        try:
            raw_streams = json.loads(raw_streams or "[]")
        except (TypeError, ValueError):
            raw_streams = []
    streams = raw_streams if isinstance(raw_streams, (list, tuple)) else []
    items = []
    for stream in streams:
        prepared = _stremio_catalog_playback_data(stream, params)
        if not prepared:
            continue
        playback_data, candidate = prepared
        url = build_url(
            "play_media",
            data=json.dumps(playback_data),
        )

        list_item = make_list_item(label=playback_data["title"])
        list_item.setProperty("IsPlayable", "true")
        info_tag = list_item.getVideoInfoTag()
        info_tag.setPlot(truncate_text(candidate.description or ""))

        items.append((url, list_item, False))

    add_directory_items_batch(items)
    end_of_directory()
