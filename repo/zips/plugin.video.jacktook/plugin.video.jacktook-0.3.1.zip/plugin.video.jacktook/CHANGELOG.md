## 0.3.1
* Add "rescrape item" context menu item to anime shows results
* Several bug fixes and some improvements

## 0.3.0
* Add Trakt support with several categories
* Update on genres menu and zilean indexer

## 0.2.9
* Add Zilean indexer support
* Minor bug fixes

## 0.2.8
* Add resume playback for videos
* Add new icons for main menu

## 0.2.7
* add "check if pack" context menu item
* several fixes and improvements

## 0.2.6
* Added service for auto-update addon 
* Added update addon setting action
* Whole refactoring of jacktook repository

## 0.2.5
* Added Plex support (beta)
* Added support for torbox debrid
* Major anime improvements
* Faster debrid fetch

## 0.2.4 (2024-04-12)
* Added jacktorr burst support
* Improvements on torrent fetch (faster resolve)
* Other minor improvements and fixes

## 0.2.3 (2024-04-06)
* Added jacktorr torrent client support
* Added jacktorr managment from addon instead of torrest
* Other minor improvements and fixes

## 0.2.2 (2024-03-22)
* Added autoplay feature
* Added clients timeouts and cache activation settings
* Added new Tmdb helper addon json
* Torrentio language improvements
* Fixed kodi 19 compatibility
* Other minor improvements and fixes

## 0.2.1 (2024-03-12)
* torrentio improvements (priority language, sort by language, etc)
* added portugese translation
* added trakt scrobbling support
* others improvements and fixes

## 0.2.0 (2024-03-04)
* Add option to select and use all torrents clients at the same time.
* Add pagination to tmdb and anilist search
* Fix for real debrid download history issue (only played videos will be saved)

## 0.1.9 (2024-02-21)
 * Fixed RD torrent stored on cloud
 * Add sort by quality to torrentio and elfhosted

## 0.1.8 (2024-02-21)
 * Add TMDB helper Addon support
 * Add new torrents menu
 * Add Elementum as another torrent client

## 0.1.7 (2024-02-21)
 * Add anime episode search
 * Add Premiumize support
 * Add Elfhosted support

## 0.1.6 (2024-02-12)
    * Fix a critical bug for Prowlarr

## 0.1.5 (2024-02-12)
    * Improvements for Prowlarr
    * Some UI changes

## 0.1.4 (2024-02-10)
    * Add Torrentio support

## 0.1.3 (2024-02-7)
    * Add "clear all cache" option on addon settings
    * Caching of indexers results
    * Improvements and fixes

## 0.1.2 (2024-02-5)

### Features

    * Add download uncached magnet to debrid option menu
    * Add show uncached option
    * Switch to torznab api for Jackett

## 0.1.1 (2024-01-30)

### Features

    * Add authentifcation flow for Realdebrid from Kodi
    
    * Fix and Update Debrid with Prowlarr Integration

    * Add new title history menu

    * Improvements on tmdb search

## 0.1.0 (2024-01-27)

### Features

    *  Real Debrid Support

    *  Improvements on tv search results

## 0.0.1 (2023-09-02)

### Features

    *  Jackett integration

    *  Torrest Integration

    *  TMDB Integration



