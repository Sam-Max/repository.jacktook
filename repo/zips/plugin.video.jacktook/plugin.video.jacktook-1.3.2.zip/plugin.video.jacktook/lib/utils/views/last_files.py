import json
import os
from lib.db.pickle_db import PickleDatabase
from lib.utils.general.utils import parse_time, set_pluging_category
from lib.utils.kodi.last_files_actions import add_last_files_context_menu
from lib.utils.kodi.utils import ADDON_HANDLE, ADDON_PATH, build_url, end_of_directory, translation

from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem


pickle_db = PickleDatabase()


def show_last_files():
    set_pluging_category(translation(90071))

    list_item = ListItem(label="Clear Files")
    list_item.setArt(
        {"icon": os.path.join(ADDON_PATH, "resources", "img", "clear.png")}
    )
    addDirectoryItem(
        ADDON_HANDLE,
        build_url("clear_history", type="lfh"),
        list_item,
    )

    all_items = list(reversed(pickle_db.get_key("jt:lfh").items()))

    items = sorted(all_items, key=parse_time, reverse=True)

    for title, data in items:
        formatted_time = data["timestamp"]
        tv_data = data.get("tv_data", {})
        if tv_data:
            season = tv_data.get("season")
            episode = tv_data.get("episode")
            name = tv_data.get("name", "")
            label = f"{title} S{season:02d}E{episode:02d} - {name} — {formatted_time}"
        else:
            label = f"{title}—{formatted_time}"

        list_item = ListItem(label=label)
        list_item.setArt(
            {"icon": os.path.join(ADDON_PATH, "resources", "img", "magnet.png")}
        )
        list_item.setProperty("IsPlayable", "true")
        list_item.addContextMenuItems(add_last_files_context_menu(data))
        addDirectoryItem(
            ADDON_HANDLE,
            build_url(
                "play_media",
                data=json.dumps(data),
            ),
            list_item,
            False,
        )
    end_of_directory()
