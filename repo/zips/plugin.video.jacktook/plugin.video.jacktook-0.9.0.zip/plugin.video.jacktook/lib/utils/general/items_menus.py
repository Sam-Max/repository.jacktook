from lib.utils.kodi.utils import translation


tv_items = [
    {
        "name": translation(90024),
        "mode": "tv",
        "api": "tmdb",
        "query": "tmdb_trending",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90025),
        "mode": "tv",
        "api": "tmdb",
        "query": "tmdb_genres",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90026),
        "mode": "tv",
        "api": "tmdb",
        "query": "tmdb_calendar",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90027),
        "mode": "tv",
        "api": "tmdb",
        "query": "tmdb_years",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90028),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_trending",
        "icon": "trakt.png",
    },
    {
        "name": translation(90029),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_watched",
        "icon": "trakt.png",
    },
    {
        "name": translation(90030),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_favorited",
        "icon": "trakt.png",
    },
    {
        "name": translation(90031),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_popular_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90032),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_trending_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90033),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_recommendations",
        "icon": "trakt.png",
    },
    {
        "name": translation(90034),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_watched_history",
        "icon": "trakt.png",
    },
    {
        "name": translation(90035),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_watchlist",
        "icon": "trakt.png",
    },
]


movie_items = [
    {
        "name": translation(90024),
        "mode": "movies",
        "api": "tmdb",
        "query": "tmdb_trending",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90025),
        "mode": "movies",
        "api": "tmdb",
        "query": "tmdb_genres",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90027),
        "mode": "movies",
        "api": "tmdb",
        "query": "tmdb_years",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90028),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_trending",
        "icon": "trakt.png",
    },
    {
        "name": translation(90036),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_top10",
        "icon": "trakt.png",
    },
    {
        "name": translation(90029),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_watched",
        "icon": "trakt.png",
    },
    {
        "name": translation(90030),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_favorited",
        "icon": "trakt.png",
    },
    {
        "name": translation(90031),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_popular_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90032),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_trending_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90033),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_recommendations",
        "icon": "trakt.png",
    },
    {
        "name": translation(90034),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_watched_history",
        "icon": "trakt.png",
    },
    {
        "name": translation(90035),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_watchlist",
        "icon": "trakt.png",
    },
]


anime_items = [
    {
        "name": translation(90037),
        "mode": "anime",
        "category": "Anime_Popular",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90038),
        "mode": "anime",
        "category": "Anime_Popular_Recent",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90039),
        "mode": "anime",
        "category": "Anime_On_The_Air",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90040),
        "mode": "anime",
        "category": "Anime_Years",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90041),
        "mode": "anime",
        "category": "Anime_Genres",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90042),
        "mode": "anime",
        "category": "Anime_Trending",
        "api": "trakt",
        "icon": "trakt.png",
    },
    {
        "name": translation(90043),
        "mode": "anime",
        "category": "Anime_Most_Watched",
        "api": "trakt",
        "icon": "trakt.png",
    },
]

animation_items = [
    {
        "name": "Cartoons Popular",
        "mode": "cartoon",
        "category": "Cartoons_Popular",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": "Animation Popular",
        "mode": "animation",
        "category": "Animation_Popular",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
]
