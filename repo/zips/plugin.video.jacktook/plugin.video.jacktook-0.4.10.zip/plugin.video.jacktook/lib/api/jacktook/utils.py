
def assure_str(s):
    return s

def str_to_bytes(s):
    return s.encode()


def bytes_to_str(b):
    return b.decode()
